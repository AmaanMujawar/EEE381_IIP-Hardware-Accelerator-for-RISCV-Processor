tb.sv contains testbench to simulate the approximate multipliers.
For 8bit multiplier simulation is over entire input combination, for 16bit inputs are chosen from a uniform distribution over the entire input range.

Result8.txt and Result16.txt contains multiplier simulation results.
