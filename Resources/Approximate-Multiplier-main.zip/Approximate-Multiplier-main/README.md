# Approximate-Multipliers
Approximate Multipliers of 8bit and 16bit operands, built with approximate compressors.

Repository part of "Performance and Error Analysis of Approximate Multipliers of Different
Configurations" paper submission to International VLSI Design & Embedded Systems conference 2022.
